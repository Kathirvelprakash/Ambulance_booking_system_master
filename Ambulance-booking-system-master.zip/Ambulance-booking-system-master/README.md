# Ambulance Booking System

This is an Android app that allows users to book ambulances conveniently. It was developed by a team of three undergraduate students at St.john's college.

**Features:**

* Login and registration
* Ambulance booking

**Contributing:**

If you would like to contribute to this project, please feel free to fork the repository and submit a pull request. We welcome all contributions, big or small.

**Credits:**

* karan singh - UI design lead
* Kathirvel  - Database operations
* Jeyfin prabu - Documentation and project refinements
![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(305).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(306).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(307).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(308).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(309).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(310).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(311).png)

![Screenshot of the project](https://github.com/nanthankaran/Ambulance-booking-system/blob/master/Screenshot%20(312).png)

